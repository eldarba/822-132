import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(private loginService: LoginService, private router:Router) {}

  ngOnInit(): void {}

  public login(email: string, password: string) {
    console.log(email + ', ' + password);
    this.loginService.login(email, password).subscribe({
      next: (token) => {
        console.log(token);
        console.log(typeof token);
        sessionStorage.setItem("token", token.toString())
        this.router.navigate(["/welcome"]);
      },
      error: (e) => {
        console.log(e.error);
        let errAsObject = JSON.parse(e.error);
        console.log(errAsObject);
        console.log(errAsObject.error);
        console.log(errAsObject.message);
        alert(errAsObject.error + ': ' + errAsObject.message);
      },
    });
  }
}
