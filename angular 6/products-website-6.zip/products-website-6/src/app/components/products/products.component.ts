import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Observable, Observer, Subscription } from 'rxjs';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  public products?: Product[];
  private subscription?: Subscription;

  constructor(private title: Title, private productsService: ProductsService) {}

  ngOnInit(): void {
    this.title.setTitle('Products');

    
    // // 1. prepare a subscriber object (given to the subscribe method)
    // let subscriber: Partial<Observer<Product[]>> = {
    //   next: (arr) => {
    //     this.products = arr;
    //     console.log('products loaded');
    //   },
    //   error: (msg) => {
    //     alert(msg);
    //   },
    //   complete: () => {
    //     this.subscription?.unsubscribe();
    //     console.log('products loading completed and unsubscribed');
    //   },
    // };
    
    // // 2. get the observable from the products service (so we can subscribe to it)
    // let observable: Observable<Product[]> = this.productsService.getAllProductsAsynch();

    // // 3. subscribe and get a subscription object
    // this.subscription = observable.subscribe(subscriber);

    this.productsService.getAllProductsHttp().subscribe({
      next: (arr) => {
        this.products = arr;
      },
      complete: () => {
        console.log('loading products completed');
      },
      error: (err) => {
        console.log(err);
        alert(err.error.error + ": " + err.error.message);
      },
    });
  }
}
