import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  public title = 'Welcome'; // string interpolation
  public hrColor = 'blue'; // property binding

  // event binding
  public buttonFn() {
    alert('button clicked');
  }

  // 2-way binding
  public x?: string;

  // ngIf
  public displayP = true;
  // ngFor
  public arr = ['aaa', 'bbb', 'ccc', 'ddd'];

  // ngStyle - an object that maps css attributes to values
  public style1 = { color: 'red', backgroundColor: 'pink' };
  // ngClass - an object that maps a css class to a boolean
  public class1 = { 'my-class': true };
}
