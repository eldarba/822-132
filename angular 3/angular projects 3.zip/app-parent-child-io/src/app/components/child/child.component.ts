import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
})
export class ChildComponent implements OnInit {
  @Input()
  public childName?: any;

  @Output()
  public childEvent: EventEmitter<string> = new EventEmitter<string>();

  constructor() {}

  ngOnInit(): void { }
  
  public fireChildEvent() {
    this.childEvent.emit(this.childName);
  }
}
