import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  // fields
  public discount: number = Math.floor(Math.random() * 26);
  public discountStyle: string = this.discount < 10 ? 'black' : 'red';
  public currDate: Date = new Date();
  public imgWidth: number = 300;
  public applyColors: boolean = false;
  public isWinter: boolean;
  public products: string[] = ['Bread', 'Peaches', 'Chease', 'Watermelons'];

  constructor() {
    let month = this.currDate.getMonth() + 1;
    this.isWinter = month <= 4 || month >= 11;
  }

  ngOnInit(): void {}

  public increaseWidth(): void {
    this.imgWidth += 10;
  }

  public decreaseWidth(): void {
    this.imgWidth -= 10;
  }

  public resetWidth(): void {
    this.imgWidth = 300;
  }
}
