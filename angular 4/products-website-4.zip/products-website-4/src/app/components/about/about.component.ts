import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css'],
})
export class AboutComponent implements OnInit {
  constructor(private title: Title) {}

  ngOnInit(): void {
    this.title.setTitle("About");
  }

  public thumbnailClicked(ev: any) {
    console.log(ev.desc);
    console.log(ev.imgSrc);
    alert('description: ' + ev.desc + ', img source: ' + ev.imgSrc);
  }
}
