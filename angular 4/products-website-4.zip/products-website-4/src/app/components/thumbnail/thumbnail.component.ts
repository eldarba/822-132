import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css'],
})
export class ThumbnailComponent implements OnInit {
  @Input()
  public imgSrc: string = ''; // type is string only
  @Input()
  public description?: string; // type is string or undefined

  @Output('imgClicked')
  public imgClickEmitter: EventEmitter<{
    imgSrc: string;
    desc: string | undefined;
  }> = new EventEmitter<{ imgSrc: string; desc: string | undefined }>();

  public imgHasBeenClicked() {
    let eventObj = { imgSrc: this.imgSrc, desc: this.description };
    this.imgClickEmitter.emit(eventObj);
  }

  constructor() {}

  ngOnInit(): void {}
}
