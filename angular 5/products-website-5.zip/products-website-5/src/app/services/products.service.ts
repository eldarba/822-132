import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  constructor(private httpClient: HttpClient) {}

  public getAllProductsHttp(): Observable<Product[]> {
    return this.httpClient.get<Product[]>('http://localhost:8080/api/product');
  }

  public getProduct(productId: number): Observable<Product> {
    return this.httpClient.get<Product>(
      'http://localhost:8080/api/product/' + productId
    );
  }

  // synchronious
  // this method should access the server to get products and return to caller
  // for now we create the products right here without accessing a real server.
  public getAllProducts(): Product[] {
    let arr: Product[] = [];
    arr.push(new Product(1, 'Milk', 14.3, 50));
    arr.push(new Product(2, 'Honey', 35.2, 25));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    arr.push(new Product(3, 'Bread', 7.9, 200));
    return arr;
  }

  // usynchronious
  public getAllProductsAsynch(): Observable<Product[]> {
    let observable = new Observable((subscriber: Subscriber<Product[]>) => {
      setTimeout(() => {
        if (Math.random() < 0.99) {
          let arr: Product[] = [];
          arr.push(new Product(1, 'Milk', 14.3, 50));
          arr.push(new Product(2, 'Honey', 35.2, 25));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          arr.push(new Product(3, 'Bread', 7.9, 200));
          subscriber.next(arr); // next - when all is ok
          subscriber.complete(); // complete when we are done
        } else {
          subscriber.error('get all products failed'); // error when action failed
        }
      }, 3000);
    });
    return observable;
  }
}
