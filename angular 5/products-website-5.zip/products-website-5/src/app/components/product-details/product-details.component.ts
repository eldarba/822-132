import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/models/product.model';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent implements OnInit {
  public product?: Product;

  constructor(
    private activatedRout: ActivatedRoute,
    private productsService: ProductsService
  ) {}

  ngOnInit(): void {
    // console.dir(this.activatedRout);
    // console.dir(this.activatedRout.snapshot.params['id']);

    let productId = this.activatedRout.snapshot.params['id']; // get the id from the route
    let subscription = this.productsService.getProduct(productId).subscribe({
      next: (p) => {
        this.product = p;
      },
      error: (err) => {
        alert(err.error.message);
      },
      complete: () => {
        subscription.unsubscribe();
      },
    });
  }
}
