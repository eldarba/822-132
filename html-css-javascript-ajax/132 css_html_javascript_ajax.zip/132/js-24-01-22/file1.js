document.getElementById("demo2").innerHTML = "External JavaScript";
